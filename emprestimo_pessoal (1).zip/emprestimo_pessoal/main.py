# -*- coding: utf-8 -*-
"""Arquivo principal do sistema Empréstimo Pessoal.

Execute com: python3 main.py
"""

from interface.aplicacao import Aplicacao


def main():
    """Cria a aplicação e inicia a interface."""
    Aplicacao().iniciar()


if __name__ == "__main__":
    main()
