# -*- coding: utf-8 -*-
"""Camada de acesso a dados: operações da tabela emprestimos."""

from dados.conexao import ErroBanco, executar


class EmprestimoDAO:
    """Executa os comandos SQL relacionados a empréstimos."""

    def inserir(self, emprestimo):
        """Registra um empréstimo, desde que o livro não esteja emprestado.

        O INSERT ... SELECT com NOT EXISTS faz a checagem e a gravação num
        único comando, então dois empréstimos simultâneos do mesmo livro
        não passam. Se nenhuma linha for inserida, o id devolvido é 0.
        """
        novo_id = executar(
            """
            INSERT INTO emprestimos (id_livro, id_pessoa, data_emprestimo, data_prevista)
            SELECT %s, %s, %s, %s
            WHERE NOT EXISTS (
                SELECT 1 FROM emprestimos
                WHERE id_livro = %s AND data_devolucao IS NULL
            )
            """,
            (
                emprestimo.id_livro,
                emprestimo.id_pessoa,
                emprestimo.data_emprestimo,
                emprestimo.data_prevista,
                emprestimo.id_livro,
            ),
        )
        if not novo_id:
            raise ErroBanco("Esse livro já está emprestado.")
        return novo_id

    def listar(self):
        """Lista todos os empréstimos, os mais recentes primeiro."""
        return executar(
            """
            SELECT e.id_emprestimo, l.titulo, p.nome,
                   e.data_emprestimo, e.data_prevista, e.data_devolucao
            FROM emprestimos e
            JOIN livros  l ON l.id_livro  = e.id_livro
            JOIN pessoas p ON p.id_pessoa = e.id_pessoa
            ORDER BY e.data_emprestimo DESC, e.id_emprestimo DESC
            """,
            consulta=True,
        )

    def registrar_devolucao(self, id_emprestimo, data_devolucao):
        """Marca o empréstimo como devolvido na data informada."""
        executar(
            "UPDATE emprestimos SET data_devolucao = %s "
            "WHERE id_emprestimo = %s AND data_devolucao IS NULL",
            (data_devolucao, id_emprestimo),
        )
