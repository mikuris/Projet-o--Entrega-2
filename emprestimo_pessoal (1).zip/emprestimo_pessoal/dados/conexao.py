# -*- coding: utf-8 -*-
"""Camada de acesso a dados: configuração e conexão com o MySQL."""

import configparser
import os

import mysql.connector
from mysql.connector import Error

# O config.ini fica na raiz do projeto (uma pasta acima de "dados").
RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CAMINHO_CONFIG = os.path.join(RAIZ, "config.ini")


class ErroBanco(Exception):
    """Erro de banco já com mensagem pronta para mostrar ao usuário."""


def ler_config():
    """Lê a seção [banco] do config.ini e devolve um dicionário.

    Levanta ErroBanco se o arquivo não existir ou estiver incompleto.
    """
    if not os.path.exists(CAMINHO_CONFIG):
        raise ErroBanco(
            "Arquivo config.ini não encontrado.\n"
            "Copie o config.exemplo.ini para config.ini e preencha os dados."
        )
    parser = configparser.ConfigParser()
    parser.read(CAMINHO_CONFIG, encoding="utf-8")
    if not parser.has_section("banco"):
        raise ErroBanco("O config.ini precisa ter a seção [banco].")

    secao = parser["banco"]
    config = {
        "host": secao.get("host", "localhost"),
        "port": secao.getint("port", 3306),
        "user": secao.get("user", ""),
        "password": secao.get("password", ""),
        "database": secao.get("database", ""),
    }
    ssl_ca = secao.get("ssl_ca", "").strip()
    if ssl_ca:
        config["ssl_ca"] = ssl_ca
    return config


def abrir_conexao():
    """Abre e devolve uma nova conexão com o banco.

    Uma conexão por operação foi a escolha mais simples: se a rede cair ou o
    servidor reiniciar, a próxima operação já tenta conectar de novo, sem
    precisar tratar conexão "velha" aberta.
    """
    config = ler_config()
    try:
        return mysql.connector.connect(charset="utf8mb4", **config)
    except Error as erro:
        raise ErroBanco(
            "Não foi possível conectar ao banco de dados.\n"
            "Verifique o config.ini e se o servidor está ligado.\n"
            f"Detalhe: {erro}"
        ) from erro


def executar(sql, parametros=(), consulta=False):
    """Executa um comando SQL e devolve o resultado.

    Se consulta=True devolve uma lista de dicionários (SELECT); caso
    contrário devolve o id gerado pelo INSERT (ou 0). Sempre usa parâmetros
    (%s) para evitar SQL injection e fecha a conexão no final.
    """
    conexao = abrir_conexao()
    try:
        cursor = conexao.cursor(dictionary=True)
        cursor.execute(sql, parametros)
        if consulta:
            return cursor.fetchall()
        conexao.commit()
        return cursor.lastrowid
    except Error as erro:
        conexao.rollback()
        # 1451/1452: violação de chave estrangeira (registro em uso).
        if erro.errno in (1451, 1452):
            raise ErroBanco(
                "Esse registro está vinculado a empréstimos e não pode ser excluído."
            ) from erro
        raise ErroBanco(f"Erro ao acessar o banco de dados.\nDetalhe: {erro}") from erro
    finally:
        conexao.close()
