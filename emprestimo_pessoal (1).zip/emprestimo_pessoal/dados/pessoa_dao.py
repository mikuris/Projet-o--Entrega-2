# -*- coding: utf-8 -*-
"""Camada de acesso a dados: operações da tabela pessoas."""

from dados.conexao import executar


class PessoaDAO:
    """Executa os comandos SQL relacionados a pessoas."""

    def inserir(self, pessoa):
        """Insere uma pessoa e devolve o id gerado."""
        return executar(
            "INSERT INTO pessoas (nome, telefone) VALUES (%s, %s)",
            (pessoa.nome, pessoa.telefone),
        )

    def listar(self):
        """Lista todas as pessoas em ordem alfabética."""
        return executar(
            "SELECT id_pessoa, nome, telefone FROM pessoas ORDER BY nome",
            consulta=True,
        )

    def atualizar(self, pessoa):
        """Atualiza nome e telefone da pessoa com o id informado."""
        executar(
            "UPDATE pessoas SET nome = %s, telefone = %s WHERE id_pessoa = %s",
            (pessoa.nome, pessoa.telefone, pessoa.id),
        )

    def excluir(self, id_pessoa):
        """Exclui a pessoa; falha com ErroBanco se ela tiver empréstimos."""
        executar("DELETE FROM pessoas WHERE id_pessoa = %s", (id_pessoa,))
