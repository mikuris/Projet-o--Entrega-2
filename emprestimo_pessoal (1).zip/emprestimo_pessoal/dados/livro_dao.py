# -*- coding: utf-8 -*-
"""Camada de acesso a dados: operações da tabela livros."""

from dados.conexao import executar

# O status do livro não é gravado na tabela: ele é calculado olhando se
# existe empréstimo ainda sem devolução. Assim nunca fica desatualizado.
_SQL_BASE = """
    SELECT l.id_livro, l.titulo, l.autor, l.ano,
           CASE WHEN EXISTS (
                    SELECT 1 FROM emprestimos e
                    WHERE e.id_livro = l.id_livro AND e.data_devolucao IS NULL
                ) THEN 'Emprestado' ELSE 'Disponível' END AS status
    FROM livros l
"""


class LivroDAO:
    """Executa os comandos SQL relacionados a livros."""

    def inserir(self, livro):
        """Insere um livro e devolve o id gerado."""
        return executar(
            "INSERT INTO livros (titulo, autor, ano) VALUES (%s, %s, %s)",
            (livro.titulo, livro.autor, livro.ano),
        )

    def listar(self, busca=""):
        """Lista os livros; se houver busca, filtra por título ou autor."""
        if busca:
            padrao = f"%{busca}%"
            return executar(
                _SQL_BASE + " WHERE l.titulo LIKE %s OR l.autor LIKE %s ORDER BY l.titulo",
                (padrao, padrao),
                consulta=True,
            )
        return executar(_SQL_BASE + " ORDER BY l.titulo", consulta=True)

    def listar_disponiveis(self):
        """Lista só os livros que não estão emprestados (para o combo de empréstimo)."""
        return [l for l in self.listar() if l["status"] == "Disponível"]

    def atualizar(self, livro):
        """Atualiza título, autor e ano do livro com o id informado."""
        executar(
            "UPDATE livros SET titulo = %s, autor = %s, ano = %s WHERE id_livro = %s",
            (livro.titulo, livro.autor, livro.ano, livro.id),
        )

    def excluir(self, id_livro):
        """Exclui o livro; falha com ErroBanco se ele tiver empréstimos."""
        executar("DELETE FROM livros WHERE id_livro = %s", (id_livro,))
