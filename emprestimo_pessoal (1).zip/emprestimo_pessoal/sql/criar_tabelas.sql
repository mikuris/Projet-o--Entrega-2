-- Script de criação do banco do sistema Empréstimo Pessoal.
-- Execute com: mysql -u SEU_USUARIO -p < sql/criar_tabelas.sql

CREATE DATABASE IF NOT EXISTS emprestimo_pessoal
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE emprestimo_pessoal;

-- Livros do acervo pessoal.
CREATE TABLE IF NOT EXISTS livros (
    id_livro INT AUTO_INCREMENT PRIMARY KEY,
    titulo   VARCHAR(150) NOT NULL,
    autor    VARCHAR(100) NOT NULL,
    ano      SMALLINT     NOT NULL
) ENGINE=InnoDB;

-- Pessoas que pegam livros emprestados (usar apenas dados fictícios).
CREATE TABLE IF NOT EXISTS pessoas (
    id_pessoa INT AUTO_INCREMENT PRIMARY KEY,
    nome      VARCHAR(100) NOT NULL,
    telefone  VARCHAR(20)  NULL
) ENGINE=InnoDB;

-- Cada empréstimo liga um livro a uma pessoa (relação N:1 com as duas tabelas).
-- data_devolucao fica NULL enquanto o livro não foi devolvido.
-- ON DELETE RESTRICT impede apagar livro ou pessoa que tenha histórico.
CREATE TABLE IF NOT EXISTS emprestimos (
    id_emprestimo  INT AUTO_INCREMENT PRIMARY KEY,
    id_livro       INT  NOT NULL,
    id_pessoa      INT  NOT NULL,
    data_emprestimo DATE NOT NULL,
    data_prevista   DATE NOT NULL,
    data_devolucao  DATE NULL,
    CONSTRAINT fk_emp_livro  FOREIGN KEY (id_livro)
        REFERENCES livros (id_livro)   ON DELETE RESTRICT,
    CONSTRAINT fk_emp_pessoa FOREIGN KEY (id_pessoa)
        REFERENCES pessoas (id_pessoa) ON DELETE RESTRICT
) ENGINE=InnoDB;
