# -*- coding: utf-8 -*-
"""Camada de interface: utilidades comuns às telas (diálogos e mensagens)."""

import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk

from dados.conexao import ErroBanco
from modelo.erros import ErroValidacao


class BaseTela:
    """Métodos compartilhados pelas telas; espera self.builder já criado."""

    def mostrar_mensagem(self, texto, tipo=Gtk.MessageType.ERROR, pai=None):
        """Exibe o diálogo de aviso do Glade com o texto e o tipo informados."""
        dialogo = self.builder.get_object("dlg_mensagem")
        dialogo.set_property("message-type", tipo)
        dialogo.set_property("text", texto)
        if pai is not None:
            dialogo.set_transient_for(pai)
        dialogo.run()
        dialogo.hide()

    def confirmar(self, texto, pai=None):
        """Pergunta Sim/Não ao usuário; devolve True se ele escolher Sim."""
        dialogo = self.builder.get_object("dlg_confirmar")
        dialogo.set_property("text", texto)
        if pai is not None:
            dialogo.set_transient_for(pai)
        resposta = dialogo.run()
        dialogo.hide()
        return resposta == Gtk.ResponseType.YES

    def executar_seguro(self, janela, acao):
        """Roda a ação e transforma erros esperados em mensagens na tela.

        É aqui que o sistema deixa de "fechar sozinho": campo inválido ou
        falha de conexão viram aviso, e a função devolve False.
        """
        try:
            acao()
            return True
        except ErroValidacao as erro:
            self.mostrar_mensagem(str(erro), Gtk.MessageType.WARNING, janela)
        except ErroBanco as erro:
            self.mostrar_mensagem(str(erro), Gtk.MessageType.ERROR, janela)
        return False

    @staticmethod
    def id_selecionado(tree):
        """Devolve o id (coluna 0) da linha selecionada, ou None."""
        modelo, linha = tree.get_selection().get_selected()
        return modelo[linha][0] if linha else None
