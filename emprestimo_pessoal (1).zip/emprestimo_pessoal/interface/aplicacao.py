# -*- coding: utf-8 -*-
"""Camada de interface: classe principal que carrega o Glade e liga as telas."""

import os

import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk

from dados.conexao import ErroBanco, abrir_conexao
from interface.base import BaseTela
from interface.tela_emprestimos import TelaEmprestimos
from interface.tela_livros import TelaLivros
from interface.tela_pessoas import TelaPessoas

ARQUIVO_GLADE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "telas.glade")


class Aplicacao(BaseTela, TelaLivros, TelaPessoas, TelaEmprestimos):
    """Junta as telas num único objeto.

    O Gtk.Builder.connect_signals aceita um só objeto com todos os handlers,
    por isso cada tela é um mixin em arquivo próprio e esta classe herda de
    todos, em vez de um arquivo gigante.
    """

    def __init__(self):
        """Carrega o .glade, conecta os sinais e prepara cada tela."""
        self.builder = Gtk.Builder()
        self.builder.add_from_file(ARQUIVO_GLADE)
        self.win_menu = self.builder.get_object("win_menu")
        self.iniciar_livros()
        self.iniciar_pessoas()
        self.iniciar_emprestimos()
        self.builder.connect_signals(self)

    def iniciar(self):
        """Testa a conexão, mostra o menu e entra no laço principal do GTK."""
        self.testar_conexao()
        self.win_menu.show()
        Gtk.main()

    def testar_conexao(self):
        """Avisa logo na abertura se o banco não estiver acessível.

        O programa continua abrindo mesmo assim: cada operação tenta
        conectar de novo e mostra a mensagem se ainda estiver falhando.
        """
        try:
            abrir_conexao().close()
        except ErroBanco as erro:
            self.mostrar_mensagem(str(erro))

    # ---- handlers do menu ----

    def on_btn_menu_livros_clicked(self, *args):
        """Esconde o menu e abre a tela de livros."""
        self.win_menu.hide()
        self.abrir_livros()

    def on_btn_menu_pessoas_clicked(self, *args):
        """Esconde o menu e abre a tela de pessoas."""
        self.win_menu.hide()
        self.abrir_pessoas()

    def on_btn_menu_emprestimos_clicked(self, *args):
        """Esconde o menu e abre a tela de empréstimos."""
        self.win_menu.hide()
        self.abrir_emprestimos()

    def on_btn_menu_sair_clicked(self, *args):
        """Destrói o menu, o que dispara on_win_menu_destroy e encerra o GTK."""
        self.win_menu.destroy()

    def on_win_menu_destroy(self, *args):
        """Encerra o laço principal quando o menu é fechado."""
        Gtk.main_quit()
