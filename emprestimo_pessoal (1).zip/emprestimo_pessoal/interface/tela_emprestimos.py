# -*- coding: utf-8 -*-
"""Camada de interface: tela de empréstimos (emprestar, listar e devolver)."""

from datetime import date

import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk

from dados.emprestimo_dao import EmprestimoDAO
from dados.livro_dao import LivroDAO
from dados.pessoa_dao import PessoaDAO
from modelo.emprestimo import Emprestimo, calcular_situacao, formatar_data


class TelaEmprestimos:
    """Handlers da janela win_emprestimos; usada como mixin da Aplicacao."""

    def iniciar_emprestimos(self):
        """Pega os widgets da tela de empréstimos e cria os DAOs."""
        self.win_emprestimos = self.builder.get_object("win_emprestimos")
        self.ls_emprestimos = self.builder.get_object("ls_emprestimos")
        self.tree_emprestimos = self.builder.get_object("tree_emprestimos")
        self.combo_emp_livro = self.builder.get_object("combo_emp_livro")
        self.combo_emp_pessoa = self.builder.get_object("combo_emp_pessoa")
        self.entry_emp_previsto = self.builder.get_object("entry_emp_previsto")
        self.emprestimo_dao = EmprestimoDAO()
        # O ComboBoxText só guarda texto, então mantemos listas paralelas
        # com os ids: o índice ativo do combo é o índice na lista de ids.
        self.ids_combo_livro = []
        self.ids_combo_pessoa = []

    def abrir_emprestimos(self):
        """Mostra a tela de empréstimos com combos e lista atualizados."""
        self.entry_emp_previsto.set_text("")
        self.carregar_combos()
        self.carregar_emprestimos()
        self.win_emprestimos.show()

    def carregar_combos(self):
        """Recarrega os combos: só livros disponíveis e todas as pessoas."""
        def acao():
            livros = LivroDAO().listar_disponiveis()
            pessoas = PessoaDAO().listar()
            self.combo_emp_livro.remove_all()
            self.combo_emp_pessoa.remove_all()
            self.ids_combo_livro = [l["id_livro"] for l in livros]
            self.ids_combo_pessoa = [p["id_pessoa"] for p in pessoas]
            for l in livros:
                self.combo_emp_livro.append_text(f"{l['titulo']} ({l['autor']})")
            for p in pessoas:
                self.combo_emp_pessoa.append_text(p["nome"])
        self.executar_seguro(self.win_emprestimos, acao)

    def carregar_emprestimos(self):
        """Preenche a lista com todos os empréstimos e a cor da situação."""
        def acao():
            emprestimos = self.emprestimo_dao.listar()
            self.ls_emprestimos.clear()
            for e in emprestimos:
                situacao, cor = calcular_situacao(e["data_prevista"], e["data_devolucao"])
                self.ls_emprestimos.append([
                    e["id_emprestimo"], e["titulo"], e["nome"],
                    formatar_data(e["data_emprestimo"]),
                    formatar_data(e["data_prevista"]),
                    situacao, cor,
                ])
        self.executar_seguro(self.win_emprestimos, acao)

    # ---- handlers ligados no Glade ----

    def on_btn_emprestar_clicked(self, *args):
        """Valida e registra um novo empréstimo com os dados do formulário."""
        def acao():
            i_livro = self.combo_emp_livro.get_active()
            i_pessoa = self.combo_emp_pessoa.get_active()
            emprestimo = Emprestimo(
                self.ids_combo_livro[i_livro] if i_livro >= 0 else None,
                self.ids_combo_pessoa[i_pessoa] if i_pessoa >= 0 else None,
                self.entry_emp_previsto.get_text(),
            )
            emprestimo.validar()
            self.emprestimo_dao.inserir(emprestimo)

        if self.executar_seguro(self.win_emprestimos, acao):
            self.entry_emp_previsto.set_text("")
            self.carregar_combos()
            self.carregar_emprestimos()

    def on_btn_devolver_clicked(self, *args):
        """Registra a devolução (hoje) do empréstimo selecionado na lista."""
        id_emp = self.id_selecionado(self.tree_emprestimos)
        if id_emp is None:
            self.mostrar_mensagem("Selecione um empréstimo na lista.",
                                  Gtk.MessageType.WARNING, self.win_emprestimos)
            return
        modelo, linha = self.tree_emprestimos.get_selection().get_selected()
        if modelo[linha][5] == "Devolvido":
            self.mostrar_mensagem("Esse empréstimo já foi devolvido.",
                                  Gtk.MessageType.INFO, self.win_emprestimos)
            return
        if not self.confirmar("Confirmar a devolução deste livro?", self.win_emprestimos):
            return
        if self.executar_seguro(
                self.win_emprestimos,
                lambda: self.emprestimo_dao.registrar_devolucao(id_emp, date.today())):
            self.carregar_combos()
            self.carregar_emprestimos()

    def on_btn_emprestimos_voltar_clicked(self, *args):
        """Fecha a tela de empréstimos e volta ao menu."""
        self.win_emprestimos.hide()
        self.win_menu.show()

    def on_win_emprestimos_delete_event(self, *args):
        """Ao fechar pelo X, só esconde a janela e volta ao menu."""
        self.on_btn_emprestimos_voltar_clicked()
        return True  # True = não destruir a janela
