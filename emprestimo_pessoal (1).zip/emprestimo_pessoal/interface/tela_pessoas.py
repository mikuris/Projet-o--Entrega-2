# -*- coding: utf-8 -*-
"""Camada de interface: tela de pessoas (CRUD completo)."""

import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk

from dados.pessoa_dao import PessoaDAO
from modelo.pessoa import Pessoa


class TelaPessoas:
    """Handlers da janela win_pessoas; usada como mixin da Aplicacao."""

    def iniciar_pessoas(self):
        """Pega os widgets da tela de pessoas e cria o DAO."""
        self.win_pessoas = self.builder.get_object("win_pessoas")
        self.ls_pessoas = self.builder.get_object("ls_pessoas")
        self.tree_pessoas = self.builder.get_object("tree_pessoas")
        self.entry_nome = self.builder.get_object("entry_nome")
        self.entry_telefone = self.builder.get_object("entry_telefone")
        self.pessoa_dao = PessoaDAO()
        self.pessoa_em_edicao = None  # id da pessoa selecionada (None = nova)

    def abrir_pessoas(self):
        """Mostra a tela de pessoas com a lista atualizada."""
        self.limpar_form_pessoa()
        self.carregar_pessoas()
        self.win_pessoas.show()

    def carregar_pessoas(self):
        """Preenche o ListStore com todas as pessoas."""
        def acao():
            pessoas = self.pessoa_dao.listar()
            self.ls_pessoas.clear()
            for p in pessoas:
                self.ls_pessoas.append([p["id_pessoa"], p["nome"], p["telefone"] or ""])
        self.executar_seguro(self.win_pessoas, acao)

    def limpar_form_pessoa(self):
        """Esvazia o formulário e volta ao modo "nova pessoa"."""
        self.pessoa_em_edicao = None
        self.entry_nome.set_text("")
        self.entry_telefone.set_text("")
        self.tree_pessoas.get_selection().unselect_all()

    # ---- handlers ligados no Glade ----

    def on_tree_pessoas_cursor_changed(self, tree):
        """Ao selecionar uma linha, copia os dados dela para o formulário."""
        modelo, linha = tree.get_selection().get_selected()
        if not linha:
            return
        self.pessoa_em_edicao = modelo[linha][0]
        self.entry_nome.set_text(modelo[linha][1])
        self.entry_telefone.set_text(modelo[linha][2])

    def on_btn_novo_pessoa_clicked(self, *args):
        """Limpa o formulário para cadastrar uma nova pessoa."""
        self.limpar_form_pessoa()
        self.entry_nome.grab_focus()

    def on_btn_salvar_pessoa_clicked(self, *args):
        """Cadastra (sem seleção) ou altera (com seleção) a pessoa do formulário."""
        def acao():
            pessoa = Pessoa(self.entry_nome.get_text(), self.entry_telefone.get_text(),
                            self.pessoa_em_edicao)
            pessoa.validar()
            if self.pessoa_em_edicao is None:
                self.pessoa_dao.inserir(pessoa)
            else:
                self.pessoa_dao.atualizar(pessoa)

        if self.executar_seguro(self.win_pessoas, acao):
            self.limpar_form_pessoa()
            self.carregar_pessoas()

    def on_btn_excluir_pessoa_clicked(self, *args):
        """Exclui a pessoa selecionada depois de pedir confirmação."""
        if self.pessoa_em_edicao is None:
            self.mostrar_mensagem("Selecione uma pessoa na lista para excluir.",
                                  Gtk.MessageType.WARNING, self.win_pessoas)
            return
        if not self.confirmar("Deseja excluir esta pessoa?", self.win_pessoas):
            return
        if self.executar_seguro(self.win_pessoas,
                                lambda: self.pessoa_dao.excluir(self.pessoa_em_edicao)):
            self.limpar_form_pessoa()
            self.carregar_pessoas()

    def on_btn_pessoas_voltar_clicked(self, *args):
        """Fecha a tela de pessoas e volta ao menu."""
        self.win_pessoas.hide()
        self.win_menu.show()

    def on_win_pessoas_delete_event(self, *args):
        """Ao fechar pelo X, só esconde a janela e volta ao menu."""
        self.on_btn_pessoas_voltar_clicked()
        return True  # True = não destruir a janela
