# -*- coding: utf-8 -*-
"""Camada de interface: tela de livros (CRUD completo)."""

import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk

from dados.livro_dao import LivroDAO
from modelo.livro import Livro


class TelaLivros:
    """Handlers da janela win_livros; usada como mixin da Aplicacao."""

    def iniciar_livros(self):
        """Pega os widgets da tela de livros e cria o DAO."""
        self.win_livros = self.builder.get_object("win_livros")
        self.ls_livros = self.builder.get_object("ls_livros")
        self.tree_livros = self.builder.get_object("tree_livros")
        self.entry_busca_livro = self.builder.get_object("entry_busca_livro")
        self.entry_titulo = self.builder.get_object("entry_titulo")
        self.entry_autor = self.builder.get_object("entry_autor")
        self.entry_ano = self.builder.get_object("entry_ano")
        self.livro_dao = LivroDAO()
        self.livro_em_edicao = None  # id do livro selecionado (None = novo)

    def abrir_livros(self):
        """Mostra a tela de livros com a lista atualizada."""
        self.limpar_form_livro()
        self.entry_busca_livro.set_text("")
        self.carregar_livros()
        self.win_livros.show()

    def carregar_livros(self, busca=""):
        """Preenche o ListStore com os livros (filtrados pela busca, se houver)."""
        def acao():
            livros = self.livro_dao.listar(busca)
            self.ls_livros.clear()
            for l in livros:
                self.ls_livros.append([l["id_livro"], l["titulo"], l["autor"],
                                       l["ano"], l["status"]])
        self.executar_seguro(self.win_livros, acao)

    def limpar_form_livro(self):
        """Esvazia o formulário e volta ao modo "novo livro"."""
        self.livro_em_edicao = None
        self.entry_titulo.set_text("")
        self.entry_autor.set_text("")
        self.entry_ano.set_text("")
        self.tree_livros.get_selection().unselect_all()

    # ---- handlers ligados no Glade ----

    def on_btn_buscar_livro_clicked(self, *args):
        """Filtra a lista pelo texto da busca (botão ou Enter no campo)."""
        self.carregar_livros(self.entry_busca_livro.get_text().strip())

    def on_tree_livros_cursor_changed(self, tree):
        """Ao selecionar uma linha, copia os dados dela para o formulário."""
        modelo, linha = tree.get_selection().get_selected()
        if not linha:
            return
        self.livro_em_edicao = modelo[linha][0]
        self.entry_titulo.set_text(modelo[linha][1])
        self.entry_autor.set_text(modelo[linha][2])
        self.entry_ano.set_text(str(modelo[linha][3]))

    def on_btn_novo_livro_clicked(self, *args):
        """Limpa o formulário para cadastrar um novo livro."""
        self.limpar_form_livro()
        self.entry_titulo.grab_focus()

    def on_btn_salvar_livro_clicked(self, *args):
        """Cadastra (sem seleção) ou altera (com seleção) o livro do formulário."""
        def acao():
            livro = Livro(self.entry_titulo.get_text(), self.entry_autor.get_text(),
                          self.entry_ano.get_text(), self.livro_em_edicao)
            livro.validar()
            if self.livro_em_edicao is None:
                self.livro_dao.inserir(livro)
            else:
                self.livro_dao.atualizar(livro)

        if self.executar_seguro(self.win_livros, acao):
            self.limpar_form_livro()
            self.carregar_livros(self.entry_busca_livro.get_text().strip())

    def on_btn_excluir_livro_clicked(self, *args):
        """Exclui o livro selecionado depois de pedir confirmação."""
        if self.livro_em_edicao is None:
            self.mostrar_mensagem("Selecione um livro na lista para excluir.",
                                  Gtk.MessageType.WARNING, self.win_livros)
            return
        if not self.confirmar("Deseja excluir este livro?", self.win_livros):
            return
        if self.executar_seguro(self.win_livros,
                                lambda: self.livro_dao.excluir(self.livro_em_edicao)):
            self.limpar_form_livro()
            self.carregar_livros(self.entry_busca_livro.get_text().strip())

    def on_btn_livros_voltar_clicked(self, *args):
        """Fecha a tela de livros e volta ao menu."""
        self.win_livros.hide()
        self.win_menu.show()

    def on_win_livros_delete_event(self, *args):
        """Ao fechar pelo X, só esconde a janela e volta ao menu."""
        self.on_btn_livros_voltar_clicked()
        return True  # True = não destruir a janela
