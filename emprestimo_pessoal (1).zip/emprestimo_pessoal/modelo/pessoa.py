# -*- coding: utf-8 -*-
"""Camada de modelo: entidade Pessoa e suas regras de validação."""

import re

from modelo.erros import ErroValidacao


class Pessoa:
    """Representa uma pessoa que pode pegar livros emprestados."""

    def __init__(self, nome, telefone, id=None):
        """Recebe os textos crus da tela e limpa os espaços das pontas."""
        self.id = id
        self.nome = (nome or "").strip()
        self.telefone = (telefone or "").strip()

    def validar(self):
        """Confere os campos; levanta ErroValidacao se algo estiver errado."""
        if not self.nome:
            raise ErroValidacao("Informe o nome da pessoa.")
        # Telefone é opcional, mas se vier só pode ter caracteres de telefone.
        if self.telefone and not re.fullmatch(r"[0-9()\-+ ]{8,20}", self.telefone):
            raise ErroValidacao("Telefone inválido. Use apenas números, espaços, ( ) - e +.")
        # Guardamos NULL em vez de texto vazio quando não há telefone.
        if not self.telefone:
            self.telefone = None
