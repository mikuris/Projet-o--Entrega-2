# -*- coding: utf-8 -*-
"""Camada de modelo: exceção usada nas validações."""


class ErroValidacao(Exception):
    """Dado inválido informado pelo usuário (mensagem pronta para exibir)."""
