# -*- coding: utf-8 -*-
"""Camada de modelo: entidade Livro e suas regras de validação."""

from datetime import date

from modelo.erros import ErroValidacao


class Livro:
    """Representa um livro do acervo."""

    def __init__(self, titulo, autor, ano, id=None):
        """Recebe os textos crus da tela e já limpa os espaços das pontas."""
        self.id = id
        self.titulo = (titulo or "").strip()
        self.autor = (autor or "").strip()
        self.ano = (ano or "").strip() if isinstance(ano, str) else ano

    def validar(self):
        """Confere os campos; levanta ErroValidacao se algo estiver errado."""
        if not self.titulo:
            raise ErroValidacao("Informe o título do livro.")
        if not self.autor:
            raise ErroValidacao("Informe o autor do livro.")
        if not str(self.ano).isdigit():
            raise ErroValidacao("O ano deve conter apenas números.")
        self.ano = int(self.ano)
        # Limite inferior arbitrário só para barrar erros de digitação.
        if not 1000 <= self.ano <= date.today().year:
            raise ErroValidacao(f"O ano deve estar entre 1000 e {date.today().year}.")
