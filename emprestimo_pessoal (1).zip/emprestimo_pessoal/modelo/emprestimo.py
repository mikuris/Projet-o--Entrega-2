# -*- coding: utf-8 -*-
"""Camada de modelo: entidade Empréstimo, regras de datas e situação."""

from datetime import date, datetime

from modelo.erros import ErroValidacao

FORMATO_TELA = "%d/%m/%Y"


def formatar_data(valor):
    """Converte um date para dd/mm/aaaa; devolve texto vazio se for None."""
    return valor.strftime(FORMATO_TELA) if valor else ""


def calcular_situacao(data_prevista, data_devolucao):
    """Devolve (texto, cor) da situação de um empréstimo.

    Devolvido = cinza; atrasado (prazo vencido sem devolução) = vermelho;
    em dia = verde. A cor é usada direto na coluna da tela.
    """
    if data_devolucao:
        return "Devolvido", "#808080"
    if data_prevista < date.today():
        return "Atrasado", "#c0392b"
    return "Em dia", "#2e8b57"


class Emprestimo:
    """Representa o empréstimo de um livro para uma pessoa."""

    def __init__(self, id_livro, id_pessoa, previsto_texto):
        """Guarda os ids escolhidos e o texto digitado da data prevista."""
        self.id_livro = id_livro
        self.id_pessoa = id_pessoa
        self.previsto_texto = (previsto_texto or "").strip()
        self.data_emprestimo = date.today()
        self.data_prevista = None

    def validar(self):
        """Confere livro, pessoa e data; levanta ErroValidacao se inválido."""
        if self.id_livro is None:
            raise ErroValidacao("Selecione um livro disponível.")
        if self.id_pessoa is None:
            raise ErroValidacao("Selecione uma pessoa.")
        if not self.previsto_texto:
            raise ErroValidacao("Informe a data prevista de devolução (dd/mm/aaaa).")
        try:
            self.data_prevista = datetime.strptime(self.previsto_texto, FORMATO_TELA).date()
        except ValueError:
            raise ErroValidacao("Data inválida. Use o formato dd/mm/aaaa.")
        if self.data_prevista < self.data_emprestimo:
            raise ErroValidacao("A data prevista não pode ser anterior a hoje.")
